package com.cello.vacu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VacuApplicationTests {

	@Test
	void contextLoads() {
	}

}
